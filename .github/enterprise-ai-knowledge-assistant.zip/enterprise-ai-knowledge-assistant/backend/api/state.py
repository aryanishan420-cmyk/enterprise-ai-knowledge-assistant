"""Shared application state, built once per app instance (no module-level singletons)."""

import threading
from dataclasses import dataclass, field
from pathlib import Path

from backend.config import Settings
from backend.database.repository import Repository
from backend.embeddings.embedding_service import Embedder
from backend.indexing.vector_store import VectorStore
from backend.ingestion import IngestionService
from backend.monitoring.metrics import Metrics
from backend.rag.chain import LLMClient, RAGChain, build_llm
from backend.retrieval.retriever import Retriever


@dataclass
class AppState:
    settings: Settings
    embedder: Embedder
    store: VectorStore
    repo: Repository
    metrics: Metrics
    retriever: Retriever
    ingestion: IngestionService
    llm: LLMClient | None = None
    _chain: RAGChain | None = None
    _lock: threading.Lock = field(default_factory=threading.Lock)

    @property
    def evaluation_path(self) -> Path:
        return Path(self.settings.vector_store_path).parent / "evaluation_results.json"

    def get_chain(self) -> RAGChain:
        """Lazily build the chain so search/ingestion work without an API key."""
        with self._lock:
            if self._chain is None:
                if self.llm is None:
                    self.llm = build_llm(self.settings)  # raises ConfigError if key missing
                self._chain = RAGChain(self.retriever, self.llm)
            return self._chain


def build_state(settings: Settings, embedder: Embedder, llm: LLMClient | None = None) -> AppState:
    store = VectorStore(settings.vector_store_path, embedder.dim, embedder.name)
    repo, metrics = Repository(settings.database_url), Metrics()
    retriever = Retriever(store, embedder, settings.top_k, settings.similarity_threshold)
    return AppState(
        settings,
        embedder,
        store,
        repo,
        metrics,
        retriever,
        IngestionService(settings, embedder, store, repo, metrics),
        llm,
    )
